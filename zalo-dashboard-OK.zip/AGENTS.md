# AGENTS.md

## Project
[ Tên project + 1 dòng mô tả làm gì ]

## Stack
- FE/BE: [Next.js / React / ...]
- DB: [Supabase / Prisma / ...]
- Deploy: [Vercel]

## Commands
- `pnpm dev`: chạy dev
- `pnpm build`: build check
- `pnpm lint`: check lỗi

## Structure
- `src/app`: routes chính
- `src/components`: UI dùng chung
- `src/lib`: utils, clients
- `src/hooks`: custom hooks

## Rules - QUAN TRỌNG
1.  **ĐỌC TRƯỚC KHI CODE:** Chỉ đọc file liên quan trực tiếp. Không đọc cả project.
2.  **KHÔNG TẠO FILE MỚI** nếu có thể sửa file cũ.
3.  **KHÔNG `npm install`** khi chưa được cho phép.
4.  Trả lời ngắn, code gọn, không giải thích dài dòng.
5.  Luôn check `package.json` trước khi đoán lib.

## IGNORE - Tiết kiệm token
BỎ QUA hoàn toàn, không bao giờ đọc/list:
- `node_modules`, `.next`, `dist`, `build`, `.git`
- `*.lock`, `pnpm-lock.yaml`
- `.env*`, `*.log`, `*.png`, `*.jpg`, `*.mp4`
- `coverage/`

## DO / DON'T
- DO: Dùng shadcn/ui, tailwind đã có sẵn
- DON'T: Tự thêm lib UI mới, tự refactor file lớn >300 dòng
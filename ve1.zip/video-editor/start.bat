@echo off
chcp 65001 >nul
title Video Editor
echo Dang khoi dong Video Editor...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause

VIDEO EDITOR DON GIAN - HUONG DAN SU DUNG
================================================

1. Double-click file start.bat
   - Lan dau mo, app se hoi duong dan ffmpeg.exe cua Ngai.
     Nhap day du, VD: D:\ffmpeg\bin\ffmpeg.exe  -> bam Luu.
   - Trinh duyet tu mo trang http://localhost:8080

2. Nap video: bam nut [📁] canh o "Video nguon" de chon file (hoac keo tha
   file tu Explorer vao o nhap) -> bam "Nap video". Tuong tu voi o nhac
   va o duong dan ffmpeg.

3. Chinh sua truc tiep tren khung hinh:
   - Cut khung: bam "Cat khung" roi keo 1 vung tren hinh.
   - Lam mo: bam "Lam mo vung" roi keo cac vung can mo (keo duoc nhieu vung).
   - Chu: bam "Them chu", keo tha de dat vi tri, sua noi dung / font / co / mau
     o cot ben trai. Co the chon font da cai trong may, dat gio hien thi.
   - Nhan dan: bam "Nhan dan", chon 1 bieu tuong, keo tha de dat vi tri.
   - Bam vao 1 muc de chon, keo goc de doi co, phim Delete de xoa.

4. Am thanh:
   - "Tat tieng goc": bo hoan toan am thanh goc cua video.
   - "Them am thanh": nhap duong dan file mp3 (hoac video khac) de ghep nhac.
     Chon "Tron voi tieng goc" hoac "Thay the tieng goc", chinh am luong.

5. Xuat video: bam "Xuat MP4 1080p". App luon xuat MP4 1080p.
   Xem tien do theo thanh mau xanh. Xong bam "Mo thu muc" de lay file.

GHI CHU
- Tat cua so den (server) de tat app.
- May khong co card roi: app dung -preset veryfast nen xuat 1080p van nhanh.
- Tat ca xu ly bang ffmpeg goc tren may Ngai, khong can mang.
- BAN DEBUG: moi thao tac duoc ghi vao file server-debug.log trong thu muc app.
  Neu gap loi, bam nut "Chuan doan" tren thanh tieu de -> "Chay chuan doan"
  -> copy ket qua gui cho Muse (kem file server-debug.log neu can).

﻿# Video Editor - backend chay tren Windows PowerShell (khong can cai them gi ngoai ffmpeg)
# Mo bang: double-click start.bat
$ErrorActionPreference = "Continue"

$root      = Split-Path -Parent $MyInvocation.MyCommand.Path
$appDir    = Join-Path $root "app"
$configPath= Join-Path $root "config.json"
$jobDir    = Join-Path $root "jobs"
$port      = 8080
$logPath   = Join-Path $root "server-debug.log"

# Nhat ky debug: moi thao tac quan trong deu ghi vao file nay
function Write-Log($msg) {
  $line = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $msg
  try { Add-Content $logPath $line -Encoding UTF8 } catch { }
}

# Kiem tra that ky: chay "ffmpeg -version" va doc output co chu "ffmpeg version" khong.
# Tra ve @{ ok=$true; version="..." } hoac @{ ok=$false; error="..." }
function Test-Ffmpeg($p) {
  try {
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = $p
    $psi.Arguments = "-version"
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $pr = [Diagnostics.Process]::Start($psi)
    $out = $pr.StandardOutput.ReadToEnd()
    $err = $pr.StandardError.ReadToEnd()
    if (!$pr.WaitForExit(15000)) {
      try { $pr.Kill() } catch { }
      return @{ ok = $false; error = "Chay thu bi treo qua 15 giay." }
    }
    if ($out -match "ffmpeg version") {
      $first = (($out -split "`r?`n") | Where-Object { $_.Trim() -ne "" } | Select-Object -First 1)
      return @{ ok = $true; version = $first.Trim() }
    }
    $e1 = (($err -split "`r?`n") | Where-Object { $_.Trim() -ne "" } | Select-Object -First 1)
    $detail = if ($e1) { " Loi he thong: $e1" } else { "" }
    return @{ ok = $false; error = "File nay khong phai ffmpeg that (khong thay chu 'ffmpeg version' trong output).$detail" }
  } catch {
    return @{ ok = $false; error = "Khong chay duoc file: $($_.Exception.Message)" }
  }
}

function Get-Config {
  if (Test-Path $configPath) {
    try { return (Get-Content $configPath -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { }
  }
  return [pscustomobject]@{ ffmpegPath = "" }
}
function Save-Config($cfg) {
  $cfg | ConvertTo-Json -Compress | Set-Content $configPath -Encoding UTF8
}
function Get-FfmpegPath {
  $c = Get-Config
  if ($c.ffmpegPath -and (Test-Path $c.ffmpegPath)) { return $c.ffmpegPath }
  return ""
}
function Get-FfprobePath($ffmpegPath) {
  if ($ffmpegPath) {
    $p = Join-Path (Split-Path $ffmpegPath -Parent) "ffprobe.exe"
    if (Test-Path $p) { return $p }
  }
  return "ffprobe"
}
function Quote($s) { return '"' + ($s -replace '"','') + '"' }

function Send-Json($ctx, $obj, $code = 200) {
  try {
    $json  = $obj | ConvertTo-Json -Depth 10 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $r = $ctx.Response
    $r.StatusCode = $code
    $r.ContentType = "application/json; charset=utf-8"
    $r.ContentLength64 = $bytes.Length
    $r.OutputStream.Write($bytes, 0, $bytes.Length)
    $r.OutputStream.Close()
  } catch { }
}

function Send-File($ctx, $path) {
  try {
    if (!(Test-Path $path -PathType Leaf)) { $ctx.Response.StatusCode = 404; $ctx.Response.Close(); return }
    $fs  = [IO.File]::OpenRead($path)
    try {
      $len = $fs.Length
      $range = $ctx.Request.Headers["Range"]
      $start = 0; $end = $len - 1; $status = 200
      if ($range -match "bytes=(\d*)-(\d*)") {
        $status = 206
        if ($matches[1] -ne "") { $start = [long]$matches[1] }
        if ($matches[2] -ne "") { $end   = [long]$matches[2] }
        if ($start -ge $len) { $start = 0 }
        if ($end -ge $len)   { $end = $len - 1 }
        if ($end -lt $start) { $end = $start }
      }
      $count = $end - $start + 1
      $ext = [IO.Path]::GetExtension($path).ToLower()
      $mime = "application/octet-stream"
      switch ($ext) {
        ".mp4"  { $mime = "video/mp4" }
        ".m4v"  { $mime = "video/mp4" }
        ".mkv"  { $mime = "video/x-matroska" }
        ".webm" { $mime = "video/webm" }
        ".avi"  { $mime = "video/x-msvideo" }
        ".mov"  { $mime = "video/quicktime" }
        ".mp3"  { $mime = "audio/mpeg" }
        ".wav"  { $mime = "audio/wav" }
        ".m4a"  { $mime = "audio/mp4" }
        ".aac"  { $mime = "audio/aac" }
      }
      $r = $ctx.Response
      $r.StatusCode = $status
      $r.ContentType = $mime
      $r.AddHeader("Accept-Ranges", "bytes")
      if ($status -eq 206) { $r.AddHeader("Content-Range", "bytes $start-$end/$len") }
      $r.ContentLength64 = $count
      $fs.Seek($start, [IO.SeekOrigin]::Begin) | Out-Null
      $buf = New-Object byte[] 65536
      $remaining = $count
      while ($remaining -gt 0) {
        $n = $fs.Read($buf, 0, [Math]::Min($buf.Length, $remaining))
        if ($n -le 0) { break }
        $r.OutputStream.Write($buf, 0, $n)
        $remaining -= $n
      }
      $r.OutputStream.Close()
    } finally { $fs.Close() }
  } catch { }
}

function Read-Body($ctx) {
  $sr = New-Object IO.StreamReader($ctx.Request.InputStream, [Text.Encoding]::UTF8)
  try { return $sr.ReadToEnd() } finally { $sr.Close() }
}
function Get-Query($url) {
  $q = @{}
  $raw = $url.Query
  if ($raw -and $raw.StartsWith("?")) {
    foreach ($pair in $raw.Substring(1).Split("&")) {
      $kv = $pair.Split("=", 2)
      if ($kv.Count -eq 2) { $q[[Net.WebUtility]::UrlDecode($kv[0])] = [Net.WebUtility]::UrlDecode($kv[1]) }
    }
  }
  return $q
}

# Doc thong tin video: thu ffprobe truoc, neu khong co thi dung "ffmpeg -i" doc stderr
function Get-MediaInfo($ffprobe, $ffmpeg, $vp) {
  $useProbe = $false
  if ($ffprobe -and $ffprobe -ne "ffprobe" -and (Test-Path $ffprobe)) { $useProbe = $true }
  else { try { $null = Get-Command ffprobe -ErrorAction Stop; $useProbe = $true; $ffprobe = "ffprobe" } catch { } }
  if ($useProbe) {
    try {
      $psi = New-Object Diagnostics.ProcessStartInfo
      $psi.FileName = $ffprobe
      $psi.Arguments = '-v error -show_format -show_streams -of json ' + (Quote $vp)
      $psi.RedirectStandardOutput = $true
      $psi.RedirectStandardError = $true
      $psi.UseShellExecute = $false
      $psi.CreateNoWindow = $true
      $pr = [Diagnostics.Process]::Start($psi)
      $out = $pr.StandardOutput.ReadToEnd()
      $pr.WaitForExit(15000) | Out-Null
      if ($pr.ExitCode -eq 0) {
        $js = $out | ConvertFrom-Json
        $vs = $js.streams | Where-Object { $_.codec_type -eq "video" } | Select-Object -First 1
        $as = $js.streams | Where-Object { $_.codec_type -eq "audio" } | Select-Object -First 1
        $fps = 0
        if ($vs.avg_frame_rate -match "(\d+)/(\d+)") { if ([int]$matches[2] -ne 0) { $fps = [math]::Round([double]$matches[1] / [double]$matches[2], 2) } }
        Write-Log "meta: ffprobe OK ${vp}"
        return @{ width = [int]$vs.width; height = [int]$vs.height; duration = [double]$js.format.duration; fps = $fps; hasAudio = ($as -ne $null); via = "ffprobe" }
      }
      Write-Log "meta: ffprobe exit code $($pr.ExitCode), chuyen sang ffmpeg -i"
    } catch { Write-Log "meta: ffprobe exception $($_.Exception.Message), chuyen sang ffmpeg -i" }
  } else {
    Write-Log "meta: khong co ffprobe, dung ffmpeg -i"
  }
  try {
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = $ffmpeg
    $psi.Arguments = '-hide_banner -i ' + (Quote $vp)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $pr = [Diagnostics.Process]::Start($psi)
    $err = $pr.StandardError.ReadToEnd()
    $pr.WaitForExit(15000) | Out-Null
    $dur = 0
    if ($err -match 'Duration: (\d+):(\d+):([\d\.]+)') { $dur = [int]$matches[1]*3600 + [int]$matches[2]*60 + [double]$matches[3] }
    $w = 0; $h = 0
    if ($err -match 'Video:[^\r\n]*?(\d+)x(\d+)') { $w = [int]$matches[1]; $h = [int]$matches[2] }
    $fps = 0
    if ($err -match '(\d+(?:\.\d+)?) fps') { $fps = [double]$matches[1] }
    $hasA = $err -match 'Stream #\d+:\d+.*Audio:'
    if ($w -gt 0) {
      Write-Log "meta: ffmpeg -i OK ${vp} (${w}x${h})"
      return @{ width = $w; height = $h; duration = $dur; fps = $fps; hasAudio = $hasA; via = "ffmpeg" }
    }
    Write-Log "meta: ffmpeg -i khong doc duoc kich thuoc"
  } catch { Write-Log "meta: ffmpeg -i exception $($_.Exception.Message)" }
  return $null
}

$jobs = @{}

$listener = New-Object Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
try {
  $listener.Start()
} catch {
  Write-Host "Khong mo duoc cong $port. Co the app dang chay roi." -ForegroundColor Red
  pause; exit 1
}
Write-Host "==============================================" -ForegroundColor Green
Write-Host "  Video Editor dang chay: http://localhost:$port" -ForegroundColor Green
Write-Host "  Dong cua so nay de tat app." -ForegroundColor Yellow
Write-Host "==============================================" -ForegroundColor Green
Write-Log "=== Server khoi dong | PS $($PSVersionTable.PSVersion) | port $port ==="
Start-Process "http://localhost:$port/"

while ($listener.IsListening) {
  $ctx = $null
  try { $ctx = $listener.GetContext() } catch { break }
  try {
    $req = $ctx.Request
    $path = $req.Url.AbsolutePath
    $method = $req.HttpMethod

    # --- Trang chinh ---
    if ($path -eq "/" -and $method -eq "GET") {
      $file = Join-Path $appDir "index.html"
      if (Test-Path $file) {
        $bytes = [IO.File]::ReadAllBytes($file)
        $ctx.Response.ContentType = "text/html; charset=utf-8"
        $ctx.Response.ContentLength64 = $bytes.Length
        $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
        $ctx.Response.OutputStream.Close()
      } else { $ctx.Response.StatusCode = 404; $ctx.Response.Close() }
      continue
    }

    # --- Ping + trang thai ffmpeg ---
    if ($path -eq "/api/ping") {
      $fp = Get-FfmpegPath
      Send-Json $ctx @{ ok = $true; ffmpeg = ($fp -ne ""); ffmpegPath = $fp }
      continue
    }

    # --- Luu duong dan ffmpeg (kiem tra ky tung buoc de debug) ---
    if ($path -eq "/api/ffmpeg-path" -and $method -eq "POST") {
      $b = (Read-Body $ctx | ConvertFrom-Json)
      $p = ([string]$b.path).Trim()
      if ($p.StartsWith('"') -and $p.EndsWith('"') -and $p.Length -gt 2) { $p = $p.Substring(1, $p.Length - 2) }
      $p = $p.Trim()
      Write-Log "ffmpeg-path: kiem tra '$p'"
      if ([IO.Path]::GetExtension($p).ToLower() -ne ".exe") {
        Write-Log "ffmpeg-path: FAIL khong phai file .exe (co ve la thu muc)"
        Send-Json $ctx @{ ok = $false; error = "Duong dan nay khong phai file .exe - co ve Ngai moi chon den thu muc. Ngai bam nut Chon file roi vao tiep cac thu muc con, chon dung file ffmpeg.exe nhe." }
        continue
      }
      if (!(Test-Path $p -PathType Leaf)) {
        Write-Log "ffmpeg-path: FAIL khong tim thay file"
        Send-Json $ctx @{ ok = $false; error = "Khong tim thay file o duong dan nay. Ngai thu bam nut Chon file de chon truc tiep cho chac." }
        continue
      }
      $t = Test-Ffmpeg $p
      if ($t.ok) {
        Save-Config ([pscustomobject]@{ ffmpegPath = $p })
        Write-Log "ffmpeg-path: OK -> $p [$($t.version)]"
        Send-Json $ctx @{ ok = $true; path = $p }
      } else {
        Write-Log "ffmpeg-path: FAIL $($t.error)"
        Send-Json $ctx @{ ok = $false; error = $t.error }
      }
      continue
    }

    # --- Thong tin video (ffprobe, du phong ffmpeg -i) ---
    if ($path -eq "/api/meta" -and $method -eq "GET") {
      $q = Get-Query $req.Url
      $vp = $q["path"]
      Write-Log "meta: yeu cau '$vp'"
      if (!$vp -or !(Test-Path $vp -PathType Leaf)) {
        Write-Log "meta: FAIL khong tim thay file"
        Send-Json $ctx @{ ok = $false; error = "Khong tim thay file video o duong dan nay." }
        continue
      }
      $fp = Get-FfmpegPath
      if (!$fp) { Send-Json $ctx @{ ok = $false; error = "Chua cau hinh ffmpeg. Ngai nhap duong dan ffmpeg truoc da." }; continue }
      $fpb = Get-FfprobePath $fp
      $info = Get-MediaInfo $fpb $fp $vp
      if (!$info) {
        Send-Json $ctx @{ ok = $false; error = "Khong doc duoc thong tin video. Mo nut Chuan doan de xem chi tiet, hoac gui file server-debug.log cho Muse." }
        continue
      }
      Send-Json $ctx @{
        ok = $true
        width = $info.width; height = $info.height
        duration = $info.duration; fps = $info.fps
        hasAudio = $info.hasAudio; via = $info.via
      }
      continue
    }

    # --- Stream file de xem truoc ---
    if ($path -eq "/api/file" -and $method -eq "GET") {
      $q = Get-Query $req.Url
      Send-File $ctx $q["path"]
      continue
    }

    # --- Danh sach font chu trong Windows ---
    if ($path -eq "/api/fonts" -and $method -eq "GET") {
      $list = @()
      foreach ($f in (Get-ChildItem "C:\Windows\Fonts" -Include *.ttf, *.otf -ErrorAction SilentlyContinue)) {
        $list += @{ name = $f.BaseName; path = $f.FullName }
      }
      $list = $list | Sort-Object name
      Send-Json $ctx @{ ok = $true; fonts = $list }
      continue
    }

    # --- Hop thoai chon file cua Windows (mo tren may nguoi dung) ---
    if ($path -eq "/api/browse" -and $method -eq "GET") {
      $q = Get-Query $req.Url
      $kind = $q["kind"]
      try {
        Add-Type -AssemblyName System.Windows.Forms | Out-Null
        $dlg = New-Object Windows.Forms.OpenFileDialog
        $dlg.Title = "Chon file"
        switch ($kind) {
          "video" { $dlg.Filter = "Video (*.mp4;*.mkv;*.avi;*.mov;*.webm;*.m4v)|*.mp4;*.mkv;*.avi;*.mov;*.webm;*.m4v|Tat ca (*.*)|*.*" }
          "audio" { $dlg.Filter = "Am thanh (*.mp3;*.wav;*.m4a;*.aac)|*.mp3;*.wav;*.m4a;*.aac|Video (lay tieng) (*.mp4;*.mkv)|*.mp4;*.mkv|Tat ca (*.*)|*.*" }
          "exe"   { $dlg.Filter = "ffmpeg.exe|ffmpeg.exe|Tat ca (*.*)|*.*" }
          default { $dlg.Filter = "Tat ca (*.*)|*.*" }
        }
        if ($dlg.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) {
          Write-Log "browse($kind): chon '$($dlg.FileName)'"
          Send-Json $ctx @{ ok = $true; path = $dlg.FileName }
        } else {
          Write-Log "browse($kind): nguoi dung bam Cancel"
          Send-Json $ctx @{ ok = $false; error = "cancel" }
        }
        $dlg.Dispose()
      } catch { Send-Json $ctx @{ ok = $false; error = "Khong mo duoc hop thoai: $($_.Exception.Message)" } }
      continue
    }

    # --- Nhan file keo tha (luu vao thu muc uploads) ---
    if ($path -eq "/api/upload" -and $method -eq "POST") {
      $q = Get-Query $req.Url
      $safe = ""
      if ($q["filename"]) { $safe = [IO.Path]::GetFileName($q["filename"]) }
      if (!$safe) { Send-Json $ctx @{ ok = $false; error = "Thieu ten file" }; continue }
      $upDir = Join-Path $root "uploads"
      if (!(Test-Path $upDir)) { New-Item -ItemType Directory -Force -Path $upDir | Out-Null }
      $base = [IO.Path]::GetFileNameWithoutExtension($safe)
      $ext  = [IO.Path]::GetExtension($safe)
      $dest = Join-Path $upDir $safe
      $i = 1
      while (Test-Path $dest) { $i++; $dest = Join-Path $upDir ($base + "_" + $i + $ext) }
      try {
        $fs = [IO.File]::Create($dest)
        try {
          $buf = New-Object byte[] 65536
          while (($n = $req.InputStream.Read($buf, 0, $buf.Length)) -gt 0) { $fs.Write($buf, 0, $n) }
        } finally { $fs.Close() }
        Write-Log "upload: nhan file -> $dest"
        Send-Json $ctx @{ ok = $true; path = $dest }
      } catch { Send-Json $ctx @{ ok = $false; error = "Upload loi: $($_.Exception.Message)" } }
      continue
    }

    # --- Chuan doan he thong (cho ban debug) ---
    if ($path -eq "/api/diag" -and $method -eq "GET") {
      $fp = Get-FfmpegPath
      $d = @{
        ok = $true
        psVersion = $PSVersionTable.PSVersion.ToString()
        ffmpegConfigured = ($fp -ne "")
        ffmpegPath = $fp
        ffmpegExists = ($fp -and (Test-Path $fp -PathType Leaf))
        ffmpegVersion = ""
        ffprobePath = ""
        ffprobeExists = $false
      }
      if ($d.ffmpegExists) {
        $t = Test-Ffmpeg $fp
        if ($t.ok) { $d.ffmpegVersion = $t.version } else { $d.ffmpegVersion = "LOI: $($t.error)" }
        $fpb = Get-FfprobePath $fp
        $d.ffprobePath = $fpb
        if ($fpb -ne "ffprobe" -and (Test-Path $fpb)) { $d.ffprobeExists = $true }
        else { try { $null = Get-Command ffprobe -ErrorAction Stop; $d.ffprobeExists = $true; $d.ffprobePath = "ffprobe (trong PATH)" } catch { } }
      }
      Write-Log "diag: ps=$($d.psVersion) ffmpeg=[$($d.ffmpegVersion)] ffprobe=$($d.ffprobeExists)"
      Send-Json $ctx $d
      continue
    }

    # --- Chay ffmpeg (export) ---
    if ($path -eq "/api/run" -and $method -eq "POST") {
      $fp = Get-FfmpegPath
      if (!$fp) { Send-Json $ctx @{ ok = $false; error = "Chua cau hinh ffmpeg" }; continue }
      $b = (Read-Body $ctx | ConvertFrom-Json)
      # PowerShell 5.1 KHONG tu boc ngoac kep cho tung phan tu -ArgumentList,
      # nen duong dan co dau cach se bi cat doi. Boc tay tung tham so:
      $args = @()
      foreach ($a in $b.args) {
        $s = ([string]$a) -replace '"', ''
        $args += '"' + $s + '"'
      }
      $durationMs = [long]$b.durationMs
      if (!(Test-Path $jobDir)) { New-Item -ItemType Directory -Force -Path $jobDir | Out-Null }
      $jobId = [guid]::NewGuid().ToString("N")
      $progFile = Join-Path $jobDir "$jobId.progress.txt"
      $errFile  = Join-Path $jobDir "$jobId.err.txt"
      if (Test-Path $progFile) { Remove-Item $progFile -Force }
      $fullArgs = $args + @("-progress", $progFile, "-nostats")
      try {
        $pr = Start-Process -FilePath $fp -ArgumentList $fullArgs -NoNewWindow -PassThru `
          -RedirectStandardError $errFile -RedirectStandardOutput (Join-Path $jobDir "$jobId.out.txt")
      } catch { Send-Json $ctx @{ ok = $false; error = "Khong chay duoc ffmpeg: $($_.Exception.Message)" }; continue }
      $jobs[$jobId] = @{
        process = $pr; progFile = $progFile; errFile = $errFile
        durationMs = $durationMs; outPath = [string]$b.outPath; done = $false
      }
      Write-Log "run: job $jobId bat dau -> $($b.outPath) ($($args.Count) tham so)"
      Send-Json $ctx @{ ok = $true; job = $jobId }
      continue
    }

    # --- Tien do export ---
    if ($path -eq "/api/progress" -and $method -eq "GET") {
      $q = Get-Query $req.Url
      $job = $jobs[$q["job"]]
      if (!$job) { Send-Json $ctx @{ ok = $false; error = "Khong tim thay job" }; continue }
      $pct = 0; $done = $false; $err = ""
      try {
        if (Test-Path $job.progFile) {
          $txt = [IO.File]::ReadAllText($job.progFile)
          $ms = [regex]::Matches($txt, "out_time_ms=(\d+)")
          if ($ms.Count -gt 0 -and $job.durationMs -gt 0) {
            $last = [long]$ms[$ms.Count - 1].Groups[1].Value
            $pct = [math]::Min(99, [math]::Round($last / ($job.durationMs * 1000) * 100))
          }
          if ($txt -match "progress=end") { $done = $true }
        }
        if ($job.process.HasExited) {
          $done = $true
          # Doc exit code that can than. Luu y: $null -ne 0 cho ra TRUE trong PowerShell,
          # nen phai kiem tra null rieng, roi lay file output thuc te lam chuan cuoi cung.
          $code = $null
          try { $code = $job.process.ExitCode } catch { $code = $null }
          $outOk = $false
          try { $outOk = (Test-Path $job.outPath -PathType Leaf) -and ((Get-Item $job.outPath).Length -gt 1024) } catch { }
          $failed = if ($code -ne $null) { $code -ne 0 } else { -not $outOk }
          if ($failed) {
            $showCode = if ($code -ne $null) { $code } else { "?" }
            $err = "ffmpeg gap loi (ma $showCode). "
            if (Test-Path $job.errFile) {
              $etail = (Get-Content $job.errFile -Tail 5 -ErrorAction SilentlyContinue) -join "`n"
              if ($etail) { $err += $etail }
            }
            Write-Log "run: job that bai (exit=$showCode)"
          } else {
            $pct = 100
            Write-Log "run: job xong (exit=$code, file output OK)"
          }
        }
        if ($done) { $job.done = $true }
      } catch { $err = $_.Exception.Message }
      Send-Json $ctx @{ ok = $true; percent = $pct; done = $done; error = $err; outPath = $job.outPath }
      continue
    }

    # --- Huy export ---
    if ($path -eq "/api/cancel" -and $method -eq "POST") {
      $b = (Read-Body $ctx | ConvertFrom-Json)
      $job = $jobs[[string]$b.job]
      if ($job -and !$job.process.HasExited) { try { $job.process.Kill() } catch { } }
      Send-Json $ctx @{ ok = $true }
      continue
    }

    # --- Mo thu muc chua file xuat ---
    if ($path -eq "/api/reveal" -and $method -eq "POST") {
      $b = (Read-Body $ctx | ConvertFrom-Json)
      $p = [string]$b.path
      if ($p -and (Test-Path $p)) { Start-Process "explorer.exe" -ArgumentList @("/select,", (Quote $p)) }
      elseif ($p) { $d = Split-Path $p -Parent; if ($d -and (Test-Path $d)) { Start-Process "explorer.exe" $d } }
      Send-Json $ctx @{ ok = $true }
      continue
    }

    $ctx.Response.StatusCode = 404
    $ctx.Response.Close()
  } catch {
    try { Send-Json $ctx @{ ok = $false; error = $_.Exception.Message } 500 } catch { }
  }
}
